pip freeze > requirements.txt
pip3 install Flask
pip3 install beautifulsoup4
pip3 install requests

docker build --tag movie_scrapper_docker .
docker run -d -p 5000:5000 movie_scrapper_docker

docker tag movie_scrapper_docker coldspidey/movie_scrapper_docker
docker push coldspidey/movie_scrapper_docker



