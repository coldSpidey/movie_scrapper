from app import app
from flask import render_template,request
from bs4 import BeautifulSoup
import requests

@app.route("/", methods = ['GET'])
def search():
    return render_template("search.html")

@app.route("/data", methods = ['POST'])
def searchResult():

    movieName = request.form.get('textSrc')
    
    url = 'https://www.imdb.com'

    # IMDB search URL
    search_query = '/search/title?title='

    # create empty library to store movie details
    movieDetails = {}

    # query format
    moviequery = search_query+'+'.join(movieName.strip().split(' '))

    # Parse the page using BeautifulSoup
    html = requests.get(url+moviequery+'&title_type=feature')
    bs = BeautifulSoup(html.text, 'html.parser')

    # Get the 1st movie
    result = bs.find('h3', {'class': 'lister-item-header'})

    if result is None:
        return None

    movielink = url+result.a.attrs['href']
    movieDetails['name'] = result.a.text

      # separate parser for plot information since it's in another page
    html = requests.get(movielink+'plotsummary')
    bs = BeautifulSoup(html.text, 'html.parser')

    # Get the 1st plot
    movieDetails['plot'] = bs.find(
        'li', {'class': 'ipl-zebra-list__item'}).p.text.strip()

    # return movieDetails
    movieTitle = movieDetails['name']
    moviePlot = movieDetails['plot']
    return render_template("result.html", moviePlot=moviePlot, movieTitle=movieTitle)
